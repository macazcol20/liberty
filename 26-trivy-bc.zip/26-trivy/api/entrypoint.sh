#!/bin/bash
set -e

echo "[entrypoint] Waiting for PostgreSQL..."
until python3 -c "
import psycopg2, os, sys
try:
    psycopg2.connect(
        host=os.environ.get('DB_HOST','postgres-service'),
        port=os.environ.get('DB_PORT',5432),
        dbname=os.environ.get('DB_NAME','trivydb'),
        user=os.environ.get('DB_USER','trivyuser'),
        password=os.environ.get('DB_PASS','trivypass')
    )
    print('DB ready')
except Exception as e:
    print(f'DB not ready: {e}')
    sys.exit(1)
" 2>/dev/null; do
    echo "[entrypoint] DB not ready, retrying in 3s..."
    sleep 3
done

echo "[entrypoint] Initializing database schema..."
python3 -c "
import sys
sys.path.insert(0, '/app')
from app import init_db
init_db()
"

echo "[entrypoint] Starting Gunicorn..."
exec gunicorn \
    --bind 0.0.0.0:5000 \
    --workers 4 \
    --timeout 660 \
    --log-level info \
    app:app
