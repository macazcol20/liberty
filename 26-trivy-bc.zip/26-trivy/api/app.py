"""
Trivy Web Application - API Backend
Runs Trivy scans, stores results in PostgreSQL, serves JSON reports with timestamps.
Email notifications handled by gmail.py (swap with ses.py if moving to SES).
"""

import os
import json
import subprocess
import uuid
import logging
from datetime import datetime, timezone
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor
import io

# ── Email module — swap this import to switch providers ──
from gmail import send_scan_email

app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# DB helpers
# ------------------------------------------------------------------

def get_db():
    return psycopg2.connect(
        host=os.environ.get("DB_HOST", "postgres-service"),
        port=int(os.environ.get("DB_PORT", 5432)),
        dbname=os.environ.get("DB_NAME", "trivydb"),
        user=os.environ.get("DB_USER", "trivyuser"),
        password=os.environ.get("DB_PASS", "trivypass"),
        cursor_factory=RealDictCursor
    )

def init_db():
    """Create tables if they don't exist."""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS builds (
            id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            build_id    TEXT NOT NULL,
            target      TEXT NOT NULL,
            scan_type   TEXT NOT NULL DEFAULT 'image',
            status      TEXT NOT NULL DEFAULT 'pending',
            started_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            finished_at TIMESTAMPTZ,
            duration_s  NUMERIC,
            raw_report  JSONB,
            summary     JSONB,
            created_by  TEXT DEFAULT 'api'
        );
        CREATE INDEX IF NOT EXISTS idx_builds_build_id ON builds(build_id);
        CREATE INDEX IF NOT EXISTS idx_builds_started_at ON builds(started_at DESC);
    """)
    conn.commit()
    cur.close()
    conn.close()
    logger.info("Database initialized")

# ------------------------------------------------------------------
# Summary helpers
# ------------------------------------------------------------------

def build_summary(trivy_json: dict) -> dict:
    summary = {
        "total_vulnerabilities": 0,
        "by_severity": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0},
        "misconfigurations": 0,
        "secrets": 0,
        "affected_packages": set(),
        "results_count": 0
    }

    results = trivy_json.get("Results", [])
    summary["results_count"] = len(results)

    for result in results:
        for vuln in result.get("Vulnerabilities", []) or []:
            sev = vuln.get("Severity", "UNKNOWN").upper()
            summary["total_vulnerabilities"] += 1
            if sev in summary["by_severity"]:
                summary["by_severity"][sev] += 1
            else:
                summary["by_severity"]["UNKNOWN"] += 1
            pkg = vuln.get("PkgName", "")
            if pkg:
                summary["affected_packages"].add(pkg)

        for m in result.get("Misconfigurations", []) or []:
            summary["misconfigurations"] += 1

        for s in result.get("Secrets", []) or []:
            summary["secrets"] += 1

    summary["affected_packages"] = list(summary["affected_packages"])
    return summary

# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()})


@app.route("/api/scan", methods=["POST"])
def trigger_scan():
    """
    POST /api/scan
    Body: { "target": "nginx:1.25", "scan_type": "image", "build_id": "build-123" }
    """
    body      = request.get_json(force=True)
    target    = body.get("target", "").strip()
    scan_type = body.get("scan_type", "image").strip()
    build_id  = body.get("build_id") or f"build-{uuid.uuid4().hex[:8]}"

    if not target:
        return jsonify({"error": "target is required"}), 400

    scan_id    = str(uuid.uuid4())
    started_at = datetime.now(timezone.utc)

    conn = get_db()
    cur  = conn.cursor()
    cur.execute(
        """INSERT INTO builds (id, build_id, target, scan_type, status, started_at)
           VALUES (%s, %s, %s, %s, 'running', %s)""",
        (scan_id, build_id, target, scan_type, started_at)
    )
    conn.commit()

    # ── Build Trivy command ──
    trivy_cmd = ["trivy", "--quiet", "--format", "json"]
    if scan_type == "image":
        trivy_cmd += ["image", "--exit-code", "0", target]
    elif scan_type == "fs":
        trivy_cmd += ["fs", "--exit-code", "0", target]
    elif scan_type == "config":
        trivy_cmd += ["config", "--exit-code", "0", target]
    elif scan_type == "sbom":
        trivy_cmd += ["sbom", "--exit-code", "0", target]
    elif scan_type == "repo":
        trivy_cmd += ["repo", "--exit-code", "0", target]
    else:
        trivy_cmd += ["image", "--exit-code", "0", target]

    logger.info("Running: %s", " ".join(trivy_cmd))

    try:
        result      = subprocess.run(trivy_cmd, capture_output=True, text=True, timeout=600)
        finished_at = datetime.now(timezone.utc)
        duration_s  = (finished_at - started_at).total_seconds()

        if result.returncode not in (0, 1):
            logger.error("Trivy stderr: %s", result.stderr)
            raw_report = {"error": result.stderr, "stdout": result.stdout}
            status     = "failed"
            summary    = {}
        else:
            raw_report = json.loads(result.stdout)
            summary    = build_summary(raw_report)
            status     = "completed"

        cur.execute(
            """UPDATE builds SET status=%s, finished_at=%s, duration_s=%s,
               raw_report=%s, summary=%s WHERE id=%s""",
            (status, finished_at, duration_s,
             json.dumps(raw_report), json.dumps(summary), scan_id)
        )
        conn.commit()

        # ── Send email notification ──
        send_scan_email(
            target     = target,
            build_id   = build_id,
            summary    = summary,
            scan_id    = scan_id,
            status     = status,
            started_at = started_at,
            duration_s = duration_s
        )

        return jsonify({
            "scan_id":     scan_id,
            "build_id":    build_id,
            "status":      status,
            "started_at":  started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "duration_s":  duration_s,
            "summary":     summary
        })

    except subprocess.TimeoutExpired:
        cur.execute("UPDATE builds SET status='timeout' WHERE id=%s", (scan_id,))
        conn.commit()
        return jsonify({"error": "Trivy scan timed out after 600s", "scan_id": scan_id}), 504
    except json.JSONDecodeError as e:
        cur.execute("UPDATE builds SET status='failed' WHERE id=%s", (scan_id,))
        conn.commit()
        return jsonify({"error": f"Failed to parse Trivy output: {e}", "scan_id": scan_id}), 500
    finally:
        cur.close()
        conn.close()


@app.route("/api/builds", methods=["GET"])
def list_builds():
    """GET /api/builds?page=1&limit=20&target=nginx"""
    page   = max(1, int(request.args.get("page", 1)))
    limit  = min(100, int(request.args.get("limit", 20)))
    target = request.args.get("target", "")
    offset = (page - 1) * limit

    conn = get_db()
    cur  = conn.cursor()

    where  = "WHERE target ILIKE %s" if target else ""
    params = [f"%{target}%", limit, offset] if target else [limit, offset]

    cur.execute(
        f"""SELECT id, build_id, target, scan_type, status,
                   started_at, finished_at, duration_s, summary
            FROM builds {where}
            ORDER BY started_at DESC
            LIMIT %s OFFSET %s""",
        params
    )
    rows = cur.fetchall()

    cur.execute(f"SELECT COUNT(*) as cnt FROM builds {where}",
                [f"%{target}%"] if target else [])
    total = cur.fetchone()["cnt"]

    cur.close()
    conn.close()

    return jsonify({
        "builds": [dict(r) for r in rows],
        "total":  total,
        "page":   page,
        "limit":  limit
    })


@app.route("/api/builds/<scan_id>", methods=["GET"])
def get_build(scan_id):
    """GET /api/builds/<scan_id> - full report including raw JSON"""
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT * FROM builds WHERE id=%s", (scan_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    if not row:
        return jsonify({"error": "not found"}), 404
    return jsonify(dict(row))


@app.route("/api/builds/<scan_id>/download", methods=["GET"])
def download_report(scan_id):
    """GET /api/builds/<scan_id>/download - download raw Trivy JSON as file"""
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT target, started_at, raw_report FROM builds WHERE id=%s", (scan_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()

    if not row or not row["raw_report"]:
        return jsonify({"error": "report not found"}), 404

    ts          = row["started_at"].strftime("%Y%m%d_%H%M%S")
    safe_target = row["target"].replace("/", "_").replace(":", "_")
    filename    = f"trivy_{safe_target}_{ts}.json"

    report_bytes = json.dumps(row["raw_report"], indent=2).encode("utf-8")
    return send_file(
        io.BytesIO(report_bytes),
        mimetype="application/json",
        as_attachment=True,
        download_name=filename
    )


@app.route("/api/stats", methods=["GET"])
def stats():
    """GET /api/stats - aggregate statistics for dashboard header"""
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        SELECT
            COUNT(*) as total_scans,
            COUNT(*) FILTER (WHERE status='completed') as completed,
            COUNT(*) FILTER (WHERE status='failed') as failed,
            COUNT(*) FILTER (WHERE status='running') as running,
            SUM((summary->>'total_vulnerabilities')::int) FILTER (WHERE status='completed') as total_vulns,
            SUM((summary->'by_severity'->>'CRITICAL')::int) FILTER (WHERE status='completed') as total_critical,
            SUM((summary->'by_severity'->>'HIGH')::int) FILTER (WHERE status='completed') as total_high
        FROM builds
    """)
    row = cur.fetchone()
    cur.close()
    conn.close()
    return jsonify(dict(row))


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
