# Trivy Web App — Step by Step Deployment

**Cluster:** `bda-k8s-world`  
**Account:** `111111111111`  
**Region:** `us-east-1`  
**Version:** `trivy-v1`  
**Namespace:** `trivy-scanner`

---

## Step 1 — ECR Login

```bash
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  111111111111.dkr.ecr.us-east-1.amazonaws.com
```

✅ Expected: `Login Succeeded`

---

## Step 2 — Create ECR Repositories

```bash
aws ecr describe-repositories --repository-names trivy-api --region us-east-1 2>/dev/null || \
aws ecr create-repository --repository-name trivy-api --region us-east-1 \
    --image-scanning-configuration scanOnPush=true \
    --encryption-configuration encryptionType=AES256
```

```bash
aws ecr describe-repositories --repository-names salsa --region us-east-1 2>/dev/null || \
aws ecr create-repository --repository-name salsa --region us-east-1 \
    --image-scanning-configuration scanOnPush=true \
    --encryption-configuration encryptionType=AES256
```

✅ Expected: JSON output showing each repository, or already exists message

---

## Step 3 — Build Trivy API Image

```bash
docker build \
  --platform linux/amd64 \
  -t trivy-api:trivy-v1 \
  -t 111111111111.dkr.ecr.us-east-1.amazonaws.com/trivy-api:trivy-v1 \
  ~/capgemini-2026/26-trivy/api/
```

✅ Expected: `FINISHED` — takes ~4-6 minutes (downloads Trivy vuln DB)

---

## Step 4 — Push Trivy API Image to ECR

```bash
docker push 111111111111.dkr.ecr.us-east-1.amazonaws.com/trivy-api:trivy-v1
```

✅ Expected: All layers pushed, `trivy-v1: digest: sha256:...`

---

## Step 5 — Build Dashboard Image

```bash
docker build \
  --platform linux/amd64 \
  -t salsa:trivy-v1 \
  -t 111111111111.dkr.ecr.us-east-1.amazonaws.com/salsa:trivy-v1 \
  ~/capgemini-2026/26-trivy/dashboard/
```

✅ Expected: `FINISHED` — takes ~30 seconds

---

## Step 6 — Push Dashboard Image to ECR

```bash
docker push 111111111111.dkr.ecr.us-east-1.amazonaws.com/salsa:trivy-v1
```

✅ Expected: All layers pushed, `trivy-v1: digest: sha256:...`

---

## Step 7 — Update kubeconfig

```bash
aws eks update-kubeconfig \
  --name bda-k8s-world \
  --region us-east-1
```

✅ Expected: `Updated context arn:aws:eks:us-east-1:111111111111:cluster/bda-k8s-world`

---

## Step 8 — Terraform Init
```sh
# Create namespace fresh
kubectl create namespace trivy-scanner

# Create ECR pull secret
kubectl create secret docker-registry ecr-secret \
  --docker-server=111111111111.dkr.ecr.us-east-1.amazonaws.com \
  --docker-username=AWS \
  --docker-password=$(aws ecr get-login-password --region us-east-1) \
  -n trivy-scanner
```

## Step 09 — Apply Kubernetes Ingress-secret

```bash
kubectl apply -f ~/capgemini-2026/26-trivy/trivy-scan-tls.yaml
```

## Step 10 — Terraform Apply

```bash
helm install trivy-scanner ~/capgemini-2026/26-trivy/trivy-helm \
  -n trivy-scanner
```

## Step 11 — Wait for Pods to be Ready

<!-- ```bash
kubectl rollout status deployment/trivy-api -n trivy-scanner --timeout=300s
```

```bash
kubectl rollout status deployment/salsa -n trivy-scanner --timeout=300s
```

```bash
kubectl rollout status deployment/postgres -n trivy-scanner --timeout=300s
``` -->


---

## Step 12 — Verify Everything is Running

```bash
kubectl get pods -n trivy-scanner
```

✅ Expected: All pods in `Running` state

```bash
kubectl get svc -n trivy-scanner
```

```bash
kubectl get ingress -n trivy-scanner
```

---

## Step 13 — Access the Dashboard

**Option A — Port forward (quick test):**
```bash
kubectl port-forward -n trivy-scanner svc/salsa-service 8080:80
```
Then open: `https://trivy.bcbs.com`

**Option B — Via Ingress hostname:**
```
http://trivy.bcbs.com
```

---

## Step 14 — Test the API (optional smoke test)

```bash
kubectl port-forward -n trivy-scanner svc/trivy-api-service 5000:5000
```

In a second terminal:
```bash
curl -X POST https://trivy.bcbs.com/api/scan \
  -H 'Content-Type: application/json' \
  -d '{"target":"nginx:latest","scan_type":"image","build_id":"test-001"}'
```

✅ Expected: JSON response with `"status": "completed"` and a summary of vulnerabilities

---

## Troubleshooting

**Check pod logs if something is not running:**
```bash
kubectl logs -n trivy-scanner deployment/trivy-api --tail=50
```

```bash
kubectl logs -n trivy-scanner deployment/salsa --tail=50
```

```bash
kubectl logs -n trivy-scanner deployment/postgres --tail=50
```

**Describe a pod that is stuck:**
```bash
kubectl describe pods -n trivy-scanner -l app=trivy-api
```


## Manually test
```sh
curl -s -X POST https://trivy.bcbs.com/api-backend/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "target":    "python:3.8",
    "scan_type": "image",
    "build_id":  "manual-test-001"
  }' | jq .
```

---

### How it flows end to end
```
docker build → docker push → curl POST /api/scan
                                      ↓
                              Trivy scans the image
                                      ↓
                         Report stored with timestamp
                                      ↓
                         Visible at trivy.bcbs.com
                         Click row → full CVE table
                         Download button → audit JSON
```


## REBUILDING Image and updating APP
```sh
docker build \
  --platform linux/amd64 \
  -t 111111111111.dkr.ecr.us-east-1.amazonaws.com/salsa:trivy-v1 \
  ~/capgemini-2026/26-trivy/dashboard/

aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  111111111111.dkr.ecr.us-east-1.amazonaws.com

docker push 111111111111.dkr.ecr.us-east-1.amazonaws.com/salsa:trivy-v1  

kubectl rollout restart deployment/salsa -n trivy-scanner