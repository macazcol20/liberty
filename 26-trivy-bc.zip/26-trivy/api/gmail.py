"""
gmail.py — Email notification module for Middleware Security Scanner
Sends scan result emails via Gmail SMTP.

To swap to SES later:
  - Replace this file with ses.py
  - Keep the same function signature: send_scan_email(...)
  - Update the import in app.py: from ses import send_scan_email
"""

import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


def send_scan_email(target, build_id, summary, scan_id, status, started_at, duration_s):
    """
    Send scan result email via Gmail SMTP.

    Required environment variables (injected from K8s secret gmail-credentials):
        SMTP_USER     — Gmail address e.g. berrkonic@gmail.com
        SMTP_PASSWORD — Gmail App Password (16 chars, no spaces)
        EMAIL_FROM    — Sender display address (defaults to SMTP_USER)
        EMAIL_TO      — Comma-separated recipient list
    """

    smtp_host     = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    smtp_port     = int(os.environ.get("SMTP_PORT", "587"))
    smtp_user     = os.environ.get("SMTP_USER", "")
    smtp_password = os.environ.get("SMTP_PASSWORD", "")
    email_from    = os.environ.get("EMAIL_FROM", smtp_user)
    email_to      = os.environ.get("EMAIL_TO", smtp_user)

    if not smtp_user or not smtp_password:
        logger.warning("SMTP credentials not configured — skipping email notification")
        return

    # ── Pull severity counts ──
    sev    = summary.get("by_severity", {})
    crit   = sev.get("CRITICAL", 0)
    high   = sev.get("HIGH", 0)
    medium = sev.get("MEDIUM", 0)
    low    = sev.get("LOW", 0)
    total  = summary.get("total_vulnerabilities", 0)
    misconf = summary.get("misconfigurations", 0)
    secrets = summary.get("secrets", 0)

    # ── Subject ──
    if crit > 0:
        subject = f"[TRIVY] 🔴 {crit} CRITICAL found — {target}"
    elif high > 0:
        subject = f"[TRIVY] 🟠 {high} HIGH found — {target}"
    else:
        subject = f"[TRIVY] ✅ Scan Complete — {target}"

    ts = started_at.strftime("%Y-%m-%d %H:%M:%S UTC") if started_at else "N/A"

    # ── Plain text body (fallback) ──
    body_text = f"""
MIDDLEWARE SECURITY SCANNER — Scan Report
==========================================

Build ID   : {build_id}
Target     : {target}
Timestamp  : {ts}
Duration   : {round(float(duration_s), 1)}s
Status     : {status.upper()}

── Vulnerability Summary ──
  CRITICAL : {crit}
  HIGH     : {high}
  MEDIUM   : {medium}
  LOW      : {low}
  ─────────────────────
  TOTAL    : {total}

── Other Findings ──
  Misconfigurations : {misconf}
  Secrets detected  : {secrets}

View full report + download JSON:
https://trivy.bcbs.com

─────────────────────────────────────────
Powered by Middleware Security Scanner
Trivy on EKS · bda-k8s-world
    """.strip()

    # ── HTML body ──
    body_html = f"""
<html>
<body style="font-family:monospace;background:#0a0c10;color:#c8cdd8;padding:24px;margin:0;">
  <div style="max-width:560px;margin:0 auto;">

    <!-- Header -->
    <div style="background:#111318;border:1px solid #1e2330;border-radius:8px;padding:24px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;border-bottom:1px solid #1e2330;padding-bottom:16px;">
        <span style="background:#3b82f6;border-radius:6px;padding:6px 10px;font-size:16px;">🛡</span>
        <div>
          <div style="font-size:14px;font-weight:600;color:#e8ecf4;letter-spacing:0.06em;">MIDDLEWARE SECURITY SCANNER</div>
          <div style="font-size:10px;color:#5a6078;letter-spacing:0.08em;">POWERED BY TRIVY</div>
        </div>
      </div>

      <!-- Meta -->
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
        <tr>
          <td style="color:#5a6078;padding:5px 0;font-size:11px;letter-spacing:0.06em;text-transform:uppercase;width:110px;">Build ID</td>
          <td style="color:#e8ecf4;font-size:12px;">{build_id}</td>
        </tr>
        <tr>
          <td style="color:#5a6078;padding:5px 0;font-size:11px;letter-spacing:0.06em;text-transform:uppercase;">Target</td>
          <td style="color:#e8ecf4;font-size:13px;font-weight:bold;">{target}</td>
        </tr>
        <tr>
          <td style="color:#5a6078;padding:5px 0;font-size:11px;letter-spacing:0.06em;text-transform:uppercase;">Timestamp</td>
          <td style="color:#e8ecf4;font-size:12px;">{ts}</td>
        </tr>
        <tr>
          <td style="color:#5a6078;padding:5px 0;font-size:11px;letter-spacing:0.06em;text-transform:uppercase;">Duration</td>
          <td style="color:#e8ecf4;font-size:12px;">{round(float(duration_s), 1)}s</td>
        </tr>
        <tr>
          <td style="color:#5a6078;padding:5px 0;font-size:11px;letter-spacing:0.06em;text-transform:uppercase;">Status</td>
          <td style="color:#22c55e;font-size:12px;font-weight:bold;">✓ {status.upper()}</td>
        </tr>
      </table>

      <!-- Severity blocks -->
      <div style="background:#0a0c10;border:1px solid #1e2330;border-radius:6px;padding:16px;margin-bottom:16px;">
        <div style="font-size:10px;letter-spacing:0.12em;text-transform:uppercase;color:#5a6078;margin-bottom:12px;">Vulnerability Summary</div>
        <table style="width:100%;border-collapse:separate;border-spacing:6px;">
          <tr>
            <td style="padding:10px;text-align:center;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);border-radius:5px;">
              <div style="font-size:22px;font-weight:bold;color:#ef4444;line-height:1;">{crit}</div>
              <div style="font-size:9px;color:#ef4444;letter-spacing:0.1em;margin-top:4px;">CRITICAL</div>
            </td>
            <td style="padding:10px;text-align:center;background:rgba(249,115,22,.12);border:1px solid rgba(249,115,22,.3);border-radius:5px;">
              <div style="font-size:22px;font-weight:bold;color:#f97316;line-height:1;">{high}</div>
              <div style="font-size:9px;color:#f97316;letter-spacing:0.1em;margin-top:4px;">HIGH</div>
            </td>
            <td style="padding:10px;text-align:center;background:rgba(234,179,8,.12);border:1px solid rgba(234,179,8,.3);border-radius:5px;">
              <div style="font-size:22px;font-weight:bold;color:#eab308;line-height:1;">{medium}</div>
              <div style="font-size:9px;color:#eab308;letter-spacing:0.1em;margin-top:4px;">MEDIUM</div>
            </td>
            <td style="padding:10px;text-align:center;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);border-radius:5px;">
              <div style="font-size:22px;font-weight:bold;color:#22c55e;line-height:1;">{low}</div>
              <div style="font-size:9px;color:#22c55e;letter-spacing:0.1em;margin-top:4px;">LOW</div>
            </td>
          </tr>
        </table>
        <div style="margin-top:12px;padding-top:10px;border-top:1px solid #1e2330;font-size:11px;color:#5a6078;">
          Total vulnerabilities: <span style="color:#3b82f6;font-weight:bold;">{total}</span>
          &nbsp;·&nbsp; Misconfigs: <span style="color:#c8cdd8;">{misconf}</span>
          &nbsp;·&nbsp; Secrets: <span style="color:#c8cdd8;">{secrets}</span>
        </div>
      </div>

      <!-- CTA Button -->
      <a href="https://trivy.bcbs.com"
         style="display:block;background:#3b82f6;color:#ffffff;text-align:center;
                padding:13px;border-radius:6px;text-decoration:none;
                font-size:13px;font-weight:500;letter-spacing:0.05em;">
        View Full Report &amp; Download JSON →
      </a>

    </div>

    <!-- Footer -->
    <div style="text-align:center;font-size:10px;color:#5a6078;letter-spacing:0.06em;">
      MIDDLEWARE SECURITY SCANNER &nbsp;·&nbsp; TRIVY ON EKS &nbsp;·&nbsp; BDA-K8S-WORLD
    </div>

  </div>
</body>
</html>
    """.strip()

    # ── Build and send ──
    recipients = [r.strip() for r in email_to.split(",")]
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = f"Middleware Security Scanner <{email_from}>"
    msg["To"]      = ", ".join(recipients)
    msg.attach(MIMEText(body_text, "plain"))
    msg.attach(MIMEText(body_html, "html"))

    try:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.ehlo()
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.sendmail(email_from, recipients, msg.as_string())
        logger.info("Email sent → %s for target [%s]", email_to, target)
    except Exception as e:
        logger.error("Email failed: %s", str(e))
