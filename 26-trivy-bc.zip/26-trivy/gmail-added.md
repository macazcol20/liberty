## Gmail setup
You need an App Password — Gmail won't allow your regular password for SMTP. Do this:
1. Enable 2FA on the Gmail account (if not already on):

***myaccount.google.com → Security → 2-Step Verification → Turn On***

2. Generate an App Password:
https://myaccount.google.com/apppasswords

appname: trivy-mail
password for app: vfcl uodx epeg yewt


nano ~/capgemini-2026/26-trivy/trivy-helm/values.yaml
# Find smtpPassword and replace "xxxx ddsd frrr sddf" with your actual app password


## Create the gmail app secret
```sh
kubectl create secret generic gmail-credentials \
  --from-literal=SMTP_HOST="smtp.gmail.com" \
  --from-literal=SMTP_PORT="587" \
  --from-literal=SMTP_USER="berrkonic@gmail.com" \
  --from-literal=SMTP_PASSWORD="vfcl uodx epeg yewt" \
  --from-literal=EMAIL_FROM="berrkonic@gmail.com" \
  --from-literal=EMAIL_TO="berrkonic@gmail.com" \
  -n trivy-scanner
  ```

3. Rebuild and push the API image (gmail.py is now inside it):

```sh
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  111111111111.dkr.ecr.us-east-1.amazonaws.com

docker build --platform linux/amd64 \
  -t 111111111111.dkr.ecr.us-east-1.amazonaws.com/trivy-api:trivy-v1 \
  ~/capgemini-2026/26-trivy/api/

docker push 111111111111.dkr.ecr.us-east-1.amazonaws.com/trivy-api:trivy-v1
```

4. Helm upgrade:
```sh
helm upgrade trivy-scanner ~/capgemini-2026/26-trivy/trivy-helm \
  -n trivy-scanner

kubectl rollout restart deployment/trivy-api -n trivy-scanner  

## test
curl -s -X POST https://trivy.bcbs.com/api-backend/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "target":    "python:3.8",
    "scan_type": "image",
    "build_id":  "manual-test-001"
  }' | jq .
 ORRRR

curl -s -X POST https://trivy.bcbs.com/api-backend/api/scan \
  -H "Content-Type: application/json" \
  -d '{"target":"nginx:latest","scan_type":"image","build_id":"email-test-001"}' | jq .status  
  ```


  ## adding crinjob to clean databases of all 72hours or more builds
  helm upgrade trivy-scanner ~/capgemini-2026/26-trivy/trivy-helm \
  -n trivy-scanner

  kubectl get cronjob -n trivy-scanner
# Step 5 — Test it manually right now (don't wait an hour):
  kubectl create job trivy-cleanup-test \
  --from=cronjob/trivy-cleanup \
  -n trivy-scanner

  kubectl logs -n trivy-scanner \
  -l job-name=trivy-cleanup-test --tail=10