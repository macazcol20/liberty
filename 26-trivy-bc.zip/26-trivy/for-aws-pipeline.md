```sh
version: 0.2

phases:
  pre_build:
    commands:
      - echo Logging in to ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | 
        docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com

  build:
    commands:
      - echo Building image...
      - docker build -t $IMAGE_REPO_NAME:$CODEBUILD_BUILD_NUMBER .
      - docker tag $IMAGE_REPO_NAME:$CODEBUILD_BUILD_NUMBER $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME:$CODEBUILD_BUILD_NUMBER

  post_build:
    commands:
      # Push to ECR
      - echo Pushing to ECR...
      - docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME:$CODEBUILD_BUILD_NUMBER

      # Send to Trivy for scanning
      - echo Sending to Trivy scanner...
      - |
        curl -s -X POST https://trivy.bcbs.com/api-backend/api/scan \
          -H "Content-Type: application/json" \
          -d "{
            \"target\":    \"$AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME:$CODEBUILD_BUILD_NUMBER\",
            \"scan_type\": \"image\",
            \"build_id\":  \"$CODEBUILD_BUILD_ID\"
          }"

      - echo Scan submitted. View report at https://trivy.bcbs.com
```

## One important thing — Trivy needs ECR access
Since Trivy is running inside your EKS cluster on bda-k8s-world, it needs permission to pull from ECR. Add this policy to your EKS node IAM role:

```sh
{
  "Effect": "Allow",
  "Action": [
    "ecr:GetAuthorizationToken",
    "ecr:BatchGetImage",
    "ecr:GetDownloadUrlForLayer"
  ],
  "Resource": "*"
}
```

### What happens in the flow
```
CodeBuild triggers
      ↓
docker build
      ↓
docker push → ECR
      ↓
curl POST → trivy.bcbs.com/api-backend/api/scan
      ↓
Trivy pulls image FROM ECR and scans it
      ↓
Report appears on trivy.bcbs.com
with build ID = CodeBuild run ID