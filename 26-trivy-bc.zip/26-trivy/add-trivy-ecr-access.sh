#!/bin/bash

# Add AWS ECR credentials to Trivy deployment
# This allows Trivy to scan images in your private ECR registry

NAMESPACE="trivy-scanner"
DEPLOYMENT="trivy-api"
AWS_ACCOUNT_ID="111111111111"
AWS_REGION="us-east-1"

echo "Creating AWS credentials secret for Trivy ECR access..."

# Get your AWS credentials
AWS_ACCESS_KEY_ID=$(aws configure get aws_access_key_id)
AWS_SECRET_ACCESS_KEY=$(aws configure get aws_secret_access_key)

# Create secret with AWS credentials
kubectl create secret generic aws-ecr-credentials \
  --from-literal=AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID \
  --from-literal=AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY \
  --from-literal=AWS_DEFAULT_REGION=$AWS_REGION \
  --namespace=$NAMESPACE \
  --dry-run=client -o yaml | kubectl apply -f -

echo "Updating Trivy deployment to use AWS credentials..."

# Patch Trivy deployment to include AWS credentials
kubectl patch deployment $DEPLOYMENT \
  --namespace=$NAMESPACE \
  --type='json' \
  -p='[
    {
      "op": "add",
      "path": "/spec/template/spec/containers/0/env/-",
      "value": {
        "name": "AWS_ACCESS_KEY_ID",
        "valueFrom": {
          "secretKeyRef": {
            "name": "aws-ecr-credentials",
            "key": "AWS_ACCESS_KEY_ID"
          }
        }
      }
    },
    {
      "op": "add",
      "path": "/spec/template/spec/containers/0/env/-",
      "value": {
        "name": "AWS_SECRET_ACCESS_KEY",
        "valueFrom": {
          "secretKeyRef": {
            "name": "aws-ecr-credentials",
            "key": "AWS_SECRET_ACCESS_KEY"
          }
        }
      }
    },
    {
      "op": "add",
      "path": "/spec/template/spec/containers/0/env/-",
      "value": {
        "name": "AWS_DEFAULT_REGION",
        "valueFrom": {
          "secretKeyRef": {
            "name": "aws-ecr-credentials",
            "key": "AWS_DEFAULT_REGION"
          }
        }
      }
    }
  ]'

echo "Waiting for Trivy pods to restart..."
kubectl rollout status deployment/$DEPLOYMENT -n $NAMESPACE

echo "✅ Trivy now has ECR access!"
echo ""
echo "Test the scan from UI with:"
echo "  368085106192.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:26.0.0.1"
echo ""
echo "Or via API:"
echo "  curl -X POST https://trivy.bcbs.com/api/scan/image \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"image\": \"368085106192.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:26.0.0.1\"}'"